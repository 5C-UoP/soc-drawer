package com.example.socdrawer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
